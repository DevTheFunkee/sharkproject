package com.dev.project.nft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NftApplicationTests {

	@Test
	void contextLoads() {
	}

}
