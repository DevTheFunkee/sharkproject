package com.dev.project.nft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NftApplication {

	public static void main(String[] args) {
		SpringApplication.run(NftApplication.class, args);
	}

}
